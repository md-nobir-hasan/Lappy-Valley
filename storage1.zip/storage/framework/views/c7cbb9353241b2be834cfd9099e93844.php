

<?php $__env->startPush('title'); ?>
    Product Details
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="card">
        <div class="card-header" style="display: flex !important ; justify-content: space-between; align-items: center">
            <h2>Product</h2>
            <h2>
                <?php if($product->upcomming): ?>
                    <span class="badge badge-success">UP COMMING <span
                            class="ml-4 badge badge-warning"><?php echo e(date('d-m-y', strtotime($product->upcomming))); ?></span>
                    </span>
                    
                <?php else: ?>
                    <?php if($product->stock > 0): ?>
                        <span class="badge badge-success">IN STOCK</span>
                    <?php else: ?>
                        <span class="badge badge-warning">OUT OF STOCK</span>
                    <?php endif; ?>
                <?php endif; ?>

            </h2>

            
            <a href="<?php echo e(url()->previous()); ?>" class="shadow-sm d btn btn-sm btn-primary" style="display: inline-block">
                
                Back</a>
        </div>
        <div class="card-body">
            <?php if($product): ?>
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Discount</th>
                            <th>Final Price</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($product->title); ?></td>
                            <td><?php echo e($product->stock); ?></td>
                            <td>৳<?php echo e(number_format($product->price, 2)); ?></td>
                            <td><?php echo e($product->discount); ?>%</td>
                            <td>৳<?php echo e($product->final_price); ?></td>
                            <td>
                                <?php if($product->status == 'active'): ?>
                                    <span class="badge badge-success"><?php echo e($product->status); ?></span>
                                <?php else: ?>
                                    <span class="badge badge-warning"><?php echo e($product->status); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('product.edit', $product->id)); ?>"
                                    class="float-left mr-1 btn btn-primary btn-sm"
                                    style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip" title="edit"
                                    data-placement="bottom"><i class="fas fa-edit"></i></a>
                                <form method="POST" action="<?php echo e(route('product.destroy', [$product->id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger btn-sm dltBtn" data-id=<?php echo e($product->id); ?>

                                        style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip"
                                        data-placement="bottom" title="Delete"><i class="fas fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <section class="confirmation_part section_padding">
                    <div class="order_boxes">
                        <div class="row">
                            <div class="col-lg-6 col-lx-4">
                                
                                <div class="order-info">
                                    <h4 class="pb-4 text-center">Product Attributes</h4>
                                    

                                    <table class="table">
                                        <tr class="">
                                            <td>Model</td>
                                            <td> : <?php echo e($product->model); ?></td>
                                        </tr>
                                        <tr class="">
                                            <td>MPN</td>
                                            <td> : <?php echo e($product->mpn); ?></td>
                                        </tr>
                                        <tr class="">
                                            <td>Category</td>
                                            <td> : <?php echo e($product->cat_info?->title); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Sub-category</td>
                                            <td> : <?php echo e($product->sub_cat_info?->title); ?> </td>
                                        </tr>
                                        <tr>
                                            <td>Brand</td>
                                            <td> : <?php echo e($product->brand?->title); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Stock</td>
                                            <td> : <?php echo e($product->stock); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Average Rating</td>
                                            <td> : <?php echo e($product->average_rating); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Views</td>
                                            <td> : <?php echo e($product->views); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Product Offer</td>
                                            <td> :
                                                <?php echo e($product->ProductOffer?->title . ' (' . $product->ProductOffer?->title . 'to' . $product->ProductOffer?->to); ?>)
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Is Featured</td>
                                            <td> : <?php echo e($product->is_featured == 1 ? 'Yes' : 'No'); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Special features</td>
                                            <td> : <?php echo e($product->special_feature); ?></td>
                                        </tr>
                                    </table>
                                </div>

                                
                                <div class="order-info">
                                    <h4 class="pb-4 text-center">Memory Attributes</h4>
                                    <table class="table">
                                        <tr>
                                            <td>RAM</td>
                                            <td> : <?php echo e($product->Ram?->name); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Memory Type</td>
                                            <td> : <?php echo e($product->m_type); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Bus Speed</td>
                                            <td> : <?php echo e($product->bus_speed); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Memory Slot</td>
                                            <td> : <?php echo e($product->m_slot); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Memory Removal</td>
                                            <td> : <?php echo e($product->m_removal ? 'Yes' : 'No'); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Other Features</td>
                                            <td> : <?php echo e($product->m_other); ?></td>
                                        </tr>

                                    </table>
                                </div>

                                
                                <div class="order-info">
                                    <h4 class="pb-4 text-center">Memory Attributes</h4>
                                    <table class="table">
                                        <tr>
                                            <td>Storage</td>
                                            <td> :
                                                <?php echo e($product->ssd?->name . ' ' . ($product->hdd ? ', ' . $product->hdd->name : '')); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Memory Type</td>
                                            <td> : <?php echo e($product->ssd ? 'SSD' : ''); ?><?php echo e($product->hdd ? ', HDD' : ''); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Bus Speed</td>
                                            <td> : <?php echo e($product->bus_speed); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Memory Slot</td>
                                            <td> : <?php echo e($product->m_slot); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Extra Slot</td>
                                            <td> : <?php echo e($product->s_extra_m2_slot ? 'Yes' : 'No'); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Storage Support Type</td>
                                            <td> : <?php echo e($product->s_support_type); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Sotrage Upgrate Note</td>
                                            <td> : <?php echo e($product->s_upgrade); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Other Features</td>
                                            <td> : <?php echo e($product->stor_other); ?></td>
                                        </tr>
                                    </table>
                                </div>

                                
                                <div class="order-info">
                                    <h4 class="pb-4 text-center">Graphic Attributes</h4>
                                    <table class="table">
                                        <tr>
                                            <td>Graphic Model</td>
                                            <td> : <?php echo e($product->g_model); ?></td>
                                        </tr>

                                        <tr>
                                            <td>Graphic Card</td>
                                            <td> : <?php echo e($product->Graphic?->name); ?></td>
                                        </tr>

                                        <tr>
                                            <td>Other Features</td>
                                            <td> : <?php echo e($product->g_other); ?></td>
                                        </tr>
                                    </table>
                                </div>

                                
                                <div class="order-info">
                                    <h4 class="pb-4 text-center">Software Attributes</h4>
                                    <table class="table">
                                        <tr>
                                            <td>Operating System</td>
                                            <td> : <?php echo e($product->operating_system); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Other Features</td>
                                            <td> : <?php echo e($product->g_other); ?></td>
                                        </tr>
                                    </table>
                                </div>

                                
                                <div class="order-info">
                                    <h4 class="pb-4 text-center">Power Attributes</h4>
                                    <table class="table">
                                        <tr>
                                            <td>Battery Type</td>
                                            <td> : <?php echo e($product->battery_type); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Battery Capacity</td>
                                            <td> : <?php echo e($product->battery_capacity); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Adapter Type</td>
                                            <td> : <?php echo e($product->adapter_type); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Other Features</td>
                                            <td> : <?php echo e($product->power_other); ?></td>
                                        </tr>
                                    </table>
                                </div>


                                
                                <div class="order-info">
                                    <h4 class="pb-4 text-center">Physical Specification</h4>
                                    <table class="table">
                                        <tr>
                                            <td>Color</td>
                                            <td> : <?php echo e($product->color); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Color</td>
                                            <td> : <?php echo e($product->dimension); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Color</td>
                                            <td> : <?php echo e($product->weight); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Other Features</td>
                                            <td> : <?php echo e($product->physi_other); ?></td>
                                        </tr>
                                    </table>
                                </div>


                                
                                <div class="order-info">
                                    <h4 class="pb-4 text-center">Warranty Attributes</h4>
                                    <table class="table">
                                        <tr>
                                            <td>Warranty Details</td>
                                            <td> : <?php echo e($product->w_details); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>

                            <div class="col-lg-6 col-lx-4">
                                <div>
                                    
                                    <div class="shipping-info">
                                        <h4 class="pb-4 text-center">Processor Attributes</h4>
                                        
                                        <table class="table">
                                            <tr>
                                                <td>Processor Model</td>
                                                <td> : <?php echo e($product->ProcessorModel?->name); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Processor Generation</td>
                                                <td> : <?php echo e($product->ProcessorGeneration?->name); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Processor Brand</td>
                                                <td> : <?php echo e($product->p_brand); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Processor Speed</td>
                                                <td> : <?php echo e($product->c_speed); ?></td>
                                            </tr>
                                            <tr>
                                                <td>L1 Cache</td>
                                                <td> : <?php echo e($product->l1_cache); ?></td>
                                            </tr>
                                            <tr>
                                                <td>L2 Cache</td>
                                                <td> : <?php echo e($product->l2_cache); ?></td>
                                            </tr>
                                            <tr>
                                                <td>L3 Cache</td>
                                                <td> : <?php echo e($product->l3_cache); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Processor Core</td>
                                                <td> : <?php echo e($product->p_core); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Processor Core</td>
                                                <td> : <?php echo e($product->p_thread); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Others Info</td>
                                                <td> : <?php echo e($product->p_other); ?></td>
                                            </tr>
                                            
                                        </table>
                                    </div>

                                    
                                    <div class="">
                                        <div class="shipping-info">
                                            <h4 class="pb-4 text-center">Display Attributes</h4>
                                            <table class="table">
                                                <tr>
                                                    <td>Display Type</td>
                                                    <td> : <?php echo e($product->DisplayType?->name); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Display Size</td>
                                                    <td> : <?php echo e($product->DisplaySize?->size); ?>

                                                        inch</td>
                                                </tr>
                                                <tr>
                                                    <td>Display Resolutioin</td>
                                                    <td> : <?php echo e($product->d_resolution); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Display</td>
                                                    <td> : <?php echo e($product->d_resolution); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Display Touch</td>
                                                    <td> : <?php echo e($product->touch_screen ? 'Yes' : 'No'); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Other Features</td>
                                                    <td> : <?php echo e($product->d_other); ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>

                                    
                                    <div class="">
                                        <div class="shipping-info">
                                            <h4 class="pb-4 text-center">Keyboar & Touchpad Attributes</h4>
                                            <table class="table">
                                                <tr>
                                                    <td>Keyboard Type</td>
                                                    <td> : <?php echo e($product->k_type); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Touchpad</td>
                                                    <td> : <?php echo e($product->touchpad ? 'Yes' : 'No'); ?></td>
                                                </tr>

                                                <tr>
                                                    <td>Other Features</td>
                                                    <td> : <?php echo e($product->k_other); ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>

                                    
                                    <div class="">
                                        <div class="shipping-info">
                                            <h4 class="pb-4 text-center">Camera & Audio Attributes</h4>
                                            <table class="table">
                                                <tr>
                                                    <td>Webcam</td>
                                                    <td> : <?php echo e($product->webcam); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Microphone</td>
                                                    <td> : <?php echo e($product->microphone); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Speaker</td>
                                                    <td> : <?php echo e($product->speaker); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Other Features</td>
                                                    <td> : <?php echo e($product->ca_other); ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>

                                    
                                    <div class="">
                                        <div class="shipping-info">
                                            <h4 class="pb-4 text-center">Ports & Slots Attributes</h4>
                                            <table class="table">
                                                <tr>
                                                    <td>Optical Driver</td>
                                                    <td> : <?php echo e($product->optical_drive); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Card Reader</td>
                                                    <td> : <?php echo e($product->card_reader); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>HDMI Port</td>
                                                    <td> : <?php echo e($product->hdmi_p); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>USB2 Port</td>
                                                    <td> : <?php echo e($product->usb2_p); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>USB3 Port</td>
                                                    <td> : <?php echo e($product->usb3_p); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Type C Therderbold Port</td>
                                                    <td> : <?php echo e($product->type_c_tb_p); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Headphone Port</td>
                                                    <td> : <?php echo e($product->headphone_p); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Microphone Port</td>
                                                    <td> : <?php echo e($product->microphone_p); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Other Features</td>
                                                    <td> : <?php echo e($product->ps_other); ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>

                                    
                                    <div class="">
                                        <div class="shipping-info">
                                            <h4 class="pb-4 text-center">Network and Connectivity Attributes</h4>
                                            <table class="table">
                                                <tr>
                                                    <td>WIFI</td>
                                                    <td> : <?php echo e($product->wifi); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Bluetooth</td>
                                                    <td> : <?php echo e($product->bluetooth); ?></td>
                                                </tr>

                                                <tr>
                                                    <td>Other Features</td>
                                                    <td> : <?php echo e($product->k_other); ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>


                                    
                                    <div class="">
                                        <div class="shipping-info">
                                            <h4 class="pb-4 text-center">Security Attributes</h4>
                                            <table class="table">
                                                <tr>
                                                    <td>Finger Print</td>
                                                    <td> : <?php echo e($product->finger_print); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Face Lock</td>
                                                    <td> : <?php echo e($product->facelock); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Other Features</td>
                                                    <td> : <?php echo e($product->s_other); ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-4 row">
                            <div class="col-12">
                                
                                <div class="shipping-info">
                                    <h4 class="pb-4 text-center">Product Summery</h4>
                                    <P>
                                        <?php echo $product->summary; ?>

                                    </P>

                                </div>

                            </div>

                        </div>
                        <div class="mt-4 row">
                            <div class="col-12">
                                
                                <div class="order-info">
                                    <h4 class="pb-4 text-center">Product Description</h4>
                                    

                                    <P>
                                        <?php echo $product->description; ?>

                                    </P>
                                </div>

                            </div>

                        </div>

                </section>

                <section class="mt-5">
                    <h1 class="text-center" style="text-decoration: underline">Products Photos</h1>
                    <div class="text-center">
                        <?php
                            $photo = explode(',', $product->photo);
                        ?>
                        <?php $__currentLoopData = $photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e($pto); ?>" class="mx-auto rounded img-fluid img-thumbnail"
                                alt="...">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .order-info,
        .shipping-info {
            background: #ECECEC;
            padding: 20px;
        }

        .order-info h4,
        .shipping-info h4 {
            text-decoration: underline;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/backend/product/show.blade.php ENDPATH**/ ?>