<?php $__env->startPush('title'); ?>
    Edit Order
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title', 'Order Detail'); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="card">
        <h5 class="card-header">Order Edit</h5>
        <div class="card-body">
            <form action="<?php echo e(route('order.update', $order->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>

                <div class="form-group">
                    <label for="payment_status">Payment Status :</label>
                    <select name="payment_status" id="payment_status" class="form-control">
                        <option value="paid" <?php if($order->payment_status == 'paid'): echo 'selected'; endif; ?>>paid</option>
                        <option value="unpaid" <?php if($order->payment_status == 'unpaid'): echo 'selected'; endif; ?>>uppaid</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="order_status_id">Status :</label>
                    <select name="status" id="order_status_id" class="form-control">
                        <?php $__currentLoopData = $order_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->title); ?>" <?php if($order->status == $item->title): echo 'selected'; endif; ?>><?php echo e($item->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .order-info,
        .shipping-info {
            background: #ECECEC;
            padding: 20px;
        }

        .order-info h4,
        .shipping-info h4 {
            text-decoration: underline;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/backend/order/edit.blade.php ENDPATH**/ ?>