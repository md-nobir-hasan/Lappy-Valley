 
 <?php $__env->startPush('title'); ?>
     <?php echo e($page_name); ?>

 <?php $__env->stopPush(); ?>
 <?php $__env->startSection('main-content'); ?>
     <div class="mb-4 shadow card">
         <div class="row">
             <div class="col-md-12">
                 <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             </div>
         </div>
         <div class="py-3 card-header d-flex justify-content-between">
             <h6 class="float-left m-0 font-weight-bold text-primary"><?php echo e($page_name); ?></h6>
         </div>



         <div class="card-body">
             <nav class="mb-2">
                 <div class="nav nav-tabs" id="nav-tab" role="tablist">
                     <button class="nav-link active" id="nav-home-tab" data-toggle="tab" data-target="#nav-home"
                         type="button" role="tab" aria-controls="nav-home" aria-selected="true">Pending</button>
                     <button class="nav-link" id="nav-profile-tab" data-toggle="tab" data-target="#nav-profile"
                         type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Delivered</button>
                     <button class="nav-link" id="nav-contact-tab" data-toggle="tab" data-target="#nav-contact"
                         type="button" role="tab" aria-controls="nav-contact" aria-selected="false">Cancelled</button>
                 </div>
             </nav>
             <div class="tab-content" id="nav-tabContent">
                 <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                     <div class="table-responsive">
                         <?php if(count($data) > 0): ?>
                             <table class="table table-bordered table-striped" id="product-dataTable" width="100%"
                                 cellspacing="0">
                                 <thead>
                                     <tr>
                                         <th>S.N.</th>
                                         <th>Order Number</th>
                                         <th>Name</th>
                                         <th>Email</th>
                                         <th>Phone</th>
                                         <th>Address</th>
                                             <th>Action</th>
                                     </tr>
                                 </thead>
                                 <tfoot>
                                     <tr>
                                         <th>S.N.</th>
                                         <th>Order Number</th>
                                         <th>Name</th>
                                         <th>Email</th>
                                         <th>Phone</th>
                                         <th>Address</th>
                                             <th>Action</th>
                                     </tr>
                                 </tfoot>
                                 <tbody>

                                     <?php $__currentLoopData = $data->where('status', 'Pending'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <tr>
                                             <td><?php echo e($pending->id); ?></td>
                                             <td><?php echo e($pending->order_number); ?></td>
                                             <td><?php echo e($pending->name); ?></td>
                                             <td><?php echo e($pending->email); ?></td>
                                             <td><?php echo e($pending->phone); ?></td>
                                             <td><?php echo e($pending->address); ?></td>
                                             <td>
                                                 <a target="_blank" href="<?php echo e(route('order.show', $pending->id)); ?>"
                                                     class="float-left mr-1 btn btn-warning btn-sm"
                                                     style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip"
                                                     title="view" data-placement="bottom"><i class="fas fa-eye"></i></a>
                                             </td>
                                         </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </tbody>
                             </table>
                         <?php else: ?>
                             <h6 class="text-center">No data found!!!</h6>
                         <?php endif; ?>
                     </div>
                 </div>
                 <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                     <div class="table-responsive">
                         <?php if(count($data->where('status', 'Delivered')) > 0): ?>
                             <table class="table table-bordered table-striped" id="product-dataTable" width="100%"
                                 cellspacing="0">
                                 <thead>
                                     <tr>
                                         <th>S.N.</th>
                                         <th>Order Number</th>
                                         <th>Name</th>
                                         <th>Email</th>
                                         <th>Phone</th>
                                         <th>Address</th>

                                             <th>Action</th>
                                         
                                     </tr>
                                 </thead>
                                 <tfoot>
                                     <tr>
                                         <th>S.N.</th>
                                         <th>Order Number</th>
                                         <th>Name</th>
                                         <th>Email</th>
                                         <th>Phone</th>
                                         <th>Address</th>

                                             <th>Action</th>
                                         
                                     </tr>
                                 </tfoot>
                                 <tbody>

                                     <?php $__currentLoopData = $data->where('status', 'Delivered'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <tr>
                                             <td><?php echo e($pending->id); ?></td>
                                             <td><?php echo e($pending->order_number); ?></td>
                                             <td><?php echo e($pending->name); ?></td>
                                             <td><?php echo e($pending->email); ?></td>
                                             <td><?php echo e($pending->phone); ?></td>
                                             <td><?php echo e($pending->address); ?></td>
                                             <td>
                                                 <a target="_blank" href="<?php echo e(route('order.show', $pending->id)); ?>"
                                                     class="float-left mr-1 btn btn-warning btn-sm"
                                                     style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip"
                                                     title="view" data-placement="bottom"><i class="fas fa-eye"></i></a>
                                             </td>
                                         </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </tbody>
                             </table>
                         <?php else: ?>
                             <h6 class="text-center">No data found!!!</h6>
                         <?php endif; ?>
                     </div>
                 </div>
                 <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                     <div class="table-responsive">
                         <?php if(count($data->where('status', 'Cancelled')) > 0): ?>
                             <table class="table table-bordered table-striped" id="product-dataTable" width="100%"
                                 cellspacing="0">
                                 <thead>
                                     <tr>
                                         <th>S.N.</th>
                                         <th>Order Number</th>
                                         <th>Name</th>
                                         <th>Email</th>
                                         <th>Phone</th>
                                         <th>Address</th>

                                             <th>Action</th>
                                         
                                     </tr>
                                 </thead>
                                 <tfoot>
                                     <tr>
                                         <th>S.N.</th>
                                         <th>Order Number</th>
                                         <th>Name</th>
                                         <th>Email</th>
                                         <th>Phone</th>
                                         <th>Address</th>

                                             <th>Action</th>
                                         
                                     </tr>
                                 </tfoot>
                                 <tbody>

                                     <?php $__currentLoopData = $data->where('status', 'Cancelled'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <tr>
                                             <td><?php echo e($pending->id); ?></td>
                                             <td><?php echo e($pending->order_number); ?></td>
                                             <td><?php echo e($pending->name); ?></td>
                                             <td><?php echo e($pending->email); ?></td>
                                             <td><?php echo e($pending->phone); ?></td>
                                             <td><?php echo e($pending->address); ?></td>
                                             <td>
                                                 <a target="_blank" href="<?php echo e(route('order.show', $pending->id)); ?>"
                                                     class="float-left mr-1 btn btn-warning btn-sm"
                                                     style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip"
                                                     title="view" data-placement="bottom"><i class="fas fa-eye"></i></a>
                                             </td>
                                         </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </tbody>
                             </table>
                         <?php else: ?>
                             <h6 class="text-center">No data found!!!</h6>
                         <?php endif; ?>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 <?php $__env->stopSection(); ?>

 <?php $__env->startPush('styles'); ?>
     <link href="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />
     <style>
         div.dataTables_wrapper div.dataTables_paginate {
             display: none;
         }

         .zoom {
             transition: transform .2s;
             /* Animation */
         }

         .zoom:hover {
             transform: scale(5);
         }
     </style>
 <?php $__env->stopPush(); ?>

 <?php $__env->startPush('scripts'); ?>
     <!-- Page level plugins -->
     <script src="<?php echo e(asset('backend/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
     <script src="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

     <!-- Page level custom scripts -->
     <script src="<?php echo e(asset('backend/js/demo/datatables-demo.js')); ?>"></script>
     <script>
         $('#product-dataTable').DataTable({
             "columnDefs": [{
                 "orderable": false,
                 "targets": [8, 9, 10]
             }]
         });

         // Sweet alert

         function deleteData(id) {

         }
     </script>
     <script>
         $(document).ready(function() {
             $.ajaxSetup({
                 headers: {
                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                 }
             });
             $('.dltBtn').click(function(e) {
                 var form = $(this).closest('form');
                 var dataID = $(this).data('id');
                 // alert(dataID);
                 e.preventDefault();
                 swal({
                         title: "Are you sure?",
                         text: "Once deleted, you will not be able to recover this data!",
                         icon: "warning",
                         buttons: true,
                         dangerMode: true,
                     })
                     .then((willDelete) => {
                         if (willDelete) {
                             form.submit();
                         } else {
                             swal("Your data is safe!");
                         }
                     });
             })
         })
     </script>
 <?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/backend/report/order/datewise.blade.php ENDPATH**/ ?>