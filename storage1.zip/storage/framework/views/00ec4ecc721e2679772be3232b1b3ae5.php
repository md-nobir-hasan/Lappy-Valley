
<div
    class="w-[221px] h-[376px] max-md:w-full mx-auto max-sm:mb-[10px] max-md:mb-[10px] max-md:gap-[8px] flex flex-col bg-white px-2 pt-2 pb-3 gap-[16px] text-left shadow-[2px_2px_5px_2px_#0000001A]">
    <div class="image-container">
        <a href="<?php echo e(route('product.details', [$product->slug])); ?>" wire:navigate>
            <!--[if BLOCK]><![endif]--><?php if($product->photo): ?>
                <?php
                    $photo = explode(',', $product->photo);
                ?>
                <img src="<?php echo e($photo[0]); ?>" class="object-container pimg h-[180px]" alt="<?php echo e($product->photo); ?>">
            <?php else: ?>
                <img src="<?php echo e(asset('backend/img/thumbnail-default.jpg')); ?>" class="object-container pimg h-[180px]" alt="avatar.png">
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </a>
    </div>
    <div>
        <a href="<?php echo e(route('product.details', [$product->slug])); ?>" wire:navigate>
            <p
                class="ptitle text-[16px] text-[#380D37] font-[jost] font-[500] leading-[23.12px] transition duration-300 ease-in-out hover:text-[#ef4a23] decoration-[#ef4a23] decoration-2 hover:underline hover:underline-offset-4">
                <?php echo e($product->title); ?>

            </p>
        </a>
    </div>
    <?php echo e($slot); ?>

    <div class="flex justify-between text-[14px] mt-auto font-[jost] font-[700] leading-[20.23px]">
        <span class="pprice text-[#DC275C]"
            value='<?php echo e($product->final_price); ?>'><?php echo e(number_format($product->final_price)); ?> TK
        </span>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('add-to-cart', ['id' => $product->id,'button' => '<p  class="font-[jost] text-[14px] text-[#380D37] font-[600] leading-[20px] text-left cursor-pointer ">Add to Cart</p>']);

$__html = app('livewire')->mount($__name, $__params, '3izVGDQ', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        
    </div>

</div>


<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/components/product.blade.php ENDPATH**/ ?>