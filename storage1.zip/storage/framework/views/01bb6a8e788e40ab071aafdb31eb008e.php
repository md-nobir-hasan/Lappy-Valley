<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title ? $title . ' || ' : ''); ?> <?php echo e(ENV('APP_NAME')); ?></title>
    <link rel="icon" href="<?php echo e(asset('storage/product/Logo.svg')); ?>" type="img/svg">
    
    
    
    <link rel="stylesheet" href="<?php echo e(asset('dist/toastr/toastr.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/tailwind-eliment/te.min.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('dist/toastr/tastr-helper.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('dist/toastr/toastr.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('library/swiper/swiper.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/owl-carousel-libraries/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dist/output.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/cstyle.css')); ?>">

</head>

<body>
    <script>
        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": true,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "preventDuplicates": false,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }
        // Display an info toast with no title
        // toastr.info('Are you the 6 fingered man?')
        // toastr.success( 'Miracle Max Says')
    </script>
    <!------- Header Section -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('header');

$__html = app('livewire')->mount($__name, $__params, 'r0Odxx5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('cart');

$__html = app('livewire')->mount($__name, $__params, '49LGCFS', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <!-------header-section-end----->

    <!--------- Nav Section -->
    <div>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('nav');

$__html = app('livewire')->mount($__name, $__params, 'ybarQME', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
    <!----------nav-end---------->

    <?php echo e($slot); ?>


    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('footer');

$__html = app('livewire')->mount($__name, $__params, 'E4wLqUG', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

  
    
    <script>
        function mFormat(money) {
            return Number(money).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, "$&,");
            //  
            //                         
        }

        // admin panel redirection
        document.addEventListener('keydown', function(event) {
            // Check if Shift and 'L' keys are pressed simultaneously
            if (event.shiftKey && event.key === 'L') {
                // Redirect to the login page
                window.location.href =
                    '<?php echo e(route('login')); ?>'; // Replace '/login' with the actual URL of your login page
            }
        });
    </script>
    
    <script src="<?php echo e(asset('frontend/owl-carousel-libraries/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/swiper/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/tailwind-eliment/te.min.js')); ?>"></script>
    <!-- Initialize Swiper -->
</body>

</html>
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>