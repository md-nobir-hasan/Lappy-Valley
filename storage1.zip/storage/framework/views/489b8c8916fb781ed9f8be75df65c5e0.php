<?php $__currentLoopData = $side_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any($smenu['access'])): ?>
        <div>
            <!-- Heading -->
            <div class="sidebar-heading">
                <?php echo e($smenu['title']); ?>

            </div>
            <?php $__currentLoopData = $smenu['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($menu['child']): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($menu['access'])): ?>
                        <li class="nav-item <?php echo e(request()->routeIs($menu['route']) ? 'active' : ''); ?>">
                            
                            <a class="nav-link <?php echo e(request()->routeIs($menu['route']) ? '' : 'collapsed'); ?>" href="#"
                                data-toggle="collapse" data-target="#n<?php echo e($loop->parent->index . $loop->index); ?>"
                                aria-expanded="true" aria-controls="collapseTwo">
                                <i class="fas fa-image"></i>
                                <span><?php echo e($menu['title']); ?></span>
                            </a>
                            <div id="n<?php echo e($loop->parent->index . $loop->index); ?>"
                                class="collapse <?php echo e(request()->routeIs($menu['route']) ? 'show' : ''); ?>"
                                aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                                <div class="py-2 bg-white rounded collapse-inner">
                                    <h6 class="collapse-header"><?php echo e(Str::singular($menu['title'])); ?> Options:</h6>
                                    <?php $__currentLoopData = $menu['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($fm['access'])): ?>
                                        <a class="collapse-item" href="<?php echo e(route($fm['route'])); ?>"><?php echo e($fm['title']); ?></a>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($menu['access'])): ?>
                        <li class="nav-item <?php echo e(request()->routeIs($menu['route']) ? 'active' : ''); ?>">
                            <a class="nav-link active" href="<?php echo e(route($menu['route'])); ?>">
                                <i class="fas fa-fw fa-chart-area"></i>
                                <span><?php echo e($menu['title']); ?></span></a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <hr class="sidebar-divider">
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/components/admin-sidebar.blade.php ENDPATH**/ ?>