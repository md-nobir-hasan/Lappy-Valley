 <div
     class="relative overflow-hidden border-[1px] border-[#380D37] rounded-[4px] box-border px-[5px] mt-2 flex flex-col bg-white shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07),0_10px_20px_-2px_rgba(0,0,0,0.04)] ">
     
     
     <!--[if BLOCK]><![endif]--><?php if($product->photo): ?>
         <?php
             $photo = explode(',', $product->photo)[0];
             // dd($photo);
         ?>
     <?php else: ?>
         <?php
             $photo = '/backend/img/thumbnail-default.jpg';
             // dd($photo);
         ?>
     <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
     <div class="flex items-center justify-center image-container">
         <a href="<?php echo e(route('product.details', [$product->slug])); ?>">
             <img src="<?php echo e($photo); ?>" class="object-container h-[180px]" alt="<?php echo e($product->title); ?>">
         </a>
     </div>
     
     
     <div class="p-4 max-sm:p-[8px] border-t-[2px] border-[#380D3733]">
         <div class=' border-[#380D3733] mb-2'>
             <a href="<?php echo e(route('product.details', [$product->slug])); ?>"
                 class="font-[jost] text-[12px] font-[500] leading-[20px] text-left text-[#380D37] transition duration-150 ease-in-out hover:text-[#ef4a23] decoration-[#ef4a23] decoration-1 hover:underline hover:underline-offset-4">
                 <?php echo e($product->title); ?>

             </a>
         </div>
         <div class='mb-4 mt-auto'>
             <ul class='text-[#353535] text-[10px] font-[jost] font-[400] list-decimal px-4 leading-[20px]'>
                 <li>Processor: AMD Ryzen 5 7520U (2.8 GHz up to 4.3 GHz)</li>
                 <li>RAM: 8GB DDR5 5500MHz, Storage: 256GB SSD</li>
                 <li>Display: 15.6" FHD (1920X1080)</li>
                 <li>Features: Type-C</li>
             </ul>
         </div>
     </div>

     <div class="px-6 py-6 mt-auto text-center border-t-[2px] border-[#380D3733]">
         <div>
             <a href="#" class="font-[jost] text-[12px] font-[700] leading-[24px] text-[#DC275C] block">
                 <?php echo e(number_format($product->final_price)); ?>

                 <span class="ml-[5px] text-[12px] font-[jost] font-[700]">TAKA</span>
             </a>
         </div>
         <div class="my-3 text-center">

             <a href="<?php echo e(route('single_checkout', [$product->slug])); ?>" wire:navigate class="">
                 <button
                     class='bg-[#380D37] text-[#F2F2F2] text-[10px] font-[jost] font-[500] py-[8px] max-lg:px-0 max-lg:w-[100px] px-[50px] rounded-[5px]'>Buy
                     Now
                 </button></a>
         </div>
         <div>
             <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('add-to-cart', ['id' => $product->id,'button' => '<p  class="font-[jost] text-[10px] text-[#380D37] font-[500] leading-[20px]">Add to Cart</p>']);

$__html = app('livewire')->mount($__name, $__params, 'BS6XarQ', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

         </div>
         
     </div>
 </div>
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/components/shop-product.blade.php ENDPATH**/ ?>