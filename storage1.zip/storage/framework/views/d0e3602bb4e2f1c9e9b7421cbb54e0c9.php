 <div class="px-[100px] max-2xl:px-[70px] max-xl:px-[60px] max-lg:px-[38px] max-md:px-[35px] max-sm:px-[15px] max-sm:mt-[70px] max-xl:mt-[100px]">
    <!--[if BLOCK]><![endif]--><?php if($success = session('success')): ?>
        <script>
            toastr.success("<?php echo e($success); ?>")
        </script>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if($error = session('error')): ?>
        <script>
            toastr.error("<?php echo e($error); ?>")
        </script>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
     <form wire:submit='orderSubmit' x-data="{
         total: <?php echo e($carts->sum('amount')); ?>,
         shipping_price: 0,
         sub_total: <?php echo e($carts->sum('amount')); ?>,
         all_total: <?php echo e($carts->sum('amount')); ?>,
         shipChange(price) {
             this.total -= this.shipping_price;
             this.total += price;
             this.shipping_price = price;
         },
         discount(){
            let res = <?php echo e($coupon); ?>;
            if (res.type == 'percent') {
                this.all_total = Math.round(this.total - (this.total * Number(res.value) / 100));
                return res.value + '%';
            } else if(res.type == 'fixed'){
                this.all_total = Math.round(this.total - Number(res.value));
                return 'BDT ' + res.value;
            }else{
                return 'BDT' + 0;
            }
         }
     }">
         <div>
             <h1 class='font-[jost] text-[16px] font-[400] leading-[25.3px] text-[#353535]'>Shopping Cart/ Checkout
             </h1>
             <div class='h-1 bg-[#764A8733]'></div>
         </div>

         <!-- -------------check-out--section----------- -->
         <div>
             <h1 class="text-[20px] text-[#353535] font-[jost] font-[500] mt-16 max-lg:mt-8 mb-4 mx-auto ">Checkout</h1>
         </div>

         <section class="grid grid-cols-3 gap-6 max-lg:gap-[0px] max-lg:grid-cols-1">
             
             <div class="grid grid-cols-1 col-span-1 max-lg:mb-[25px]">
                 <div class="border-[3px] border-[#380D37] rounded-[5px] p-[20px]">
                     <div class="flex gap-[15px] font-[jost] font-[500] text-center">
                         <div class="w-[22px] h-[22px] bg-[#380D37] text-[#F2F2F2] rounded-[100%] text-center mt-[5px]">
                             <h1>1</h1>
                         </div>
                         <div>
                             <h1 class="text-[#380D37] text-[20px] font-[jost] font-[500] tracking-[.5px] text-center">
                                 Customer Information</h1>
                         </div>
                     </div>

                     <div class="flex max-xl:flex-col gap-[15px] my-[10px] w-full">
                         <div class="w-full">
                             <label class="block font-[jost] font-[500] text-[#353535] text-[12px]" for="name">
                                 First Name*</label>
                             <input name="name" id="name"
                                 class=" w-full py-[10px] pl-[10px] border-[1px] border-[#380D37] italic rounded-[4px] font-[jost] font-[500] text-[12px] text-[#380D37] placeholder-[#C4C4C4]"
                                 type="text" placeholder="First Name*"
                                 <?php if(auth()->user()): ?> value='<?php echo e(auth()->user()->name ?? old('name')); ?>' <?php else: ?> value='<?php echo e(old('name')); ?>' <?php endif; ?>
                                 wire:model='name'>
                             <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <span class="text-[red] text-[12px]"><?php echo e($message); ?></span>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                         </div>
                         <div class="w-full">
                             <label class="block font-[jost] font-[500] text-[#353535] text-[12px]" for="f_name">
                                 Last Name*</label>
                             <input name="l_name" id="l_name"
                                 class=" w-full py-[10px] pl-[10px] border-[1px] border-[#380D37] italic rounded-[4px] font-[jost] font-[500] text-[12px] text-[#380D37] placeholder-[#C4C4C4]"
                                 type="text"
                                 <?php if(auth()->user()): ?> value='<?php echo e(auth()->user()->l_name ?? old('l_name')); ?>' <?php else: ?> value='<?php echo e(old('l_name')); ?>' <?php endif; ?>
                                 placeholder="Last Name*"
                                 wire:model='l_name'>
                             <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['l_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <span class="text-[red] text-[12px]"><?php echo e($message); ?></span>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                         </div>
                     </div>

                     <div class="my-[10px]">
                         <label class="block font-[jost] font-[500] text-[#353535] text-[12px]"
                             for="address">Address*</label>
                         <input name="address" id="address"
                             class="w-full py-[10px] pl-[10px] border-[1px] border-[#380D37] italic rounded-[4px] font-[jost] font-[500] text-[12px] text-[#380D37] placeholder-[#C4C4C4]"
                             type="text" placeholder="Address*"
                             <?php if(auth()->user()): ?> value='<?php echo e(auth()->user()->name ?? old('address')); ?>' <?php else: ?> value='<?php echo e(old('address')); ?>' <?php endif; ?>
                             wire:model='address'>
                         <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <span class="text-[red] text-[12px]"><?php echo e($message); ?></span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                     </div>

                     <div class="my-[10px]">
                         <label class="block font-[jost] font-[500] text-[#353535] text-[12px]"
                             for="phone">Mobile*</label>
                         <input name="phone" id="phone"
                             class=" w-full py-[10px] pl-[10px] border-[1px] border-[#380D37] italic rounded-[4px] font-[jost] font-[500] text-[12px] text-[#380D37] placeholder-[#C4C4C4]"
                             type="number" placeholder="Mobile Number*"
                             <?php if(auth()->user()): ?> value='<?php echo e(auth()->user()->phone ?? old('phone')); ?>' <?php else: ?> value='<?php echo e(old('phone')); ?>' <?php endif; ?>
                             wire:model='phone'>
                         <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <span class="text-[red] text-[12px]"><?php echo e($message); ?></span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                     </div>

                     <div class="my-[10px]">
                         <label class="block font-[jost] font-[500] text-[#353535] text-[12px]"
                             for="email">Email:</label>
                         <input name="email" id="email"
                             class=" w-full py-[10px] pl-[10px] border-[1px] border-[#380D37] italic rounded-[4px] font-[jost] font-[500] text-[12px] text-[#380D37] placeholder-[#C4C4C4]"
                             type="email" placeholder="Email:"
                             <?php if(auth()->user()): ?> value='<?php echo e(auth()->user()->email ?? old('email')); ?>' <?php else: ?> value='<?php echo e(old('email')); ?>' <?php endif; ?>
                             wire:model='email'>
                         <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <span class="text-[red] text-[12px]"><?php echo e($message); ?></span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                     </div>

                     <div class="flex max-xl:flex-col gap-[15px] my-[10px] w-full">
                         <div class="w-full">
                             <label class="block font-[jost] font-[500] text-[#353535] text-[12px]"
                                 for="city">City*</label>
                             <input name="city" id="city"
                                 class=" w-full py-[10px] pl-[10px] border-[1px] border-[#380D37] italic rounded-[4px] font-[jost] font-[500] text-[12px] text-[#380D37] placeholder-[#C4C4C4]"
                                 type="text" placeholder="City*"
                                 <?php if(auth()->user()): ?> value='<?php echo e(auth()->user()->city ?? old('city')); ?>' <?php else: ?> value='<?php echo e(old('city')); ?>' <?php endif; ?>
                                 wire:model='city'>
                             <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <span class="text-[red] text-[12px]"><?php echo e($message); ?></span>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                         </div>
                         <div class="w-full">
                             <label class="block font-[jost] font-[500] text-[#353535] text-[12px]"
                                 for="divission_id">Zone*</label>
                             <select name="divission_id" id="divission_id"
                                 class="w-full py-[10px] pl-[10px] border-[1px] rounded-[4px] italic border-[#380D37] font-[jost] font-[500] text-[12px] text-[#380D37] placeholder-[#C4C4C4]"
                                 wire:model='divission_id'>
                                 <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $divissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($division->id); ?>" <?php if($division->id == old('divission_id')): echo 'selected'; endif; ?>>
                                         <?php echo e($division->name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                             </select>
                             <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['divission_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <span class="text-[red] text-[12px]"><?php echo e($message); ?></span>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                         </div>
                     </div>

                     <div>
                         <label class="block font-[jost] font-[500] text-[#353535] text-[12px]"
                             for="comment">Comment:</label>
                         <input id="comment"
                             class="w-full pt-[10px] pb-[80px] pl-[10px] border-[1px] border-[#380D37] italic rounded-[4px] font-[jost] font-[500] text-[12px] text-[#380D37] placeholder-[#C4C4C4]"
                             type="text" placeholder="comment"
                             wire:model='comment'>
                         <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <span class="text-[red] text-[12px]"><?php echo e($message); ?></span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                     </div>
                 </div>
             </div>

             <div class="col-span-2">
                 
                 <div class="grid grid-cols-2 gap-4 max-sm:grid-cols-1">

                     
                     <div class="border-[#380D37] border-[3px] rounded-[4px] p-[20px]">

                         <div class="flex gap-[15px] font-[jost] font-[500] text-center my-[10px]">
                             <div
                                 class="w-[22px] h-[22px] bg-[#380D37] text-[#f2f2f2] rounded-[100%] text-center mt-[5px]">
                                 <h1>2</h1>
                             </div>
                             <div>
                                 <h1
                                     class="text-[#380D37] text-[20px] font-[jost] font-[500] tracking-[.5px] text-center">
                                     Payment Method</h1>
                             </div>
                         </div>
                         <div class="my-[10px]">
                             <h1 class="text-[#353535] text-[14px] font-[jost] font-[500]">Select Payment Method</h1>
                         </div>
                         <div class="my-[10px] flex items-center gap-[5px]">
                             <input name="payment_method" id="cod" class="w-[14px] h-[14px] accent-[#380D37]"
                                  type="radio" value="cod"
                                 wire:model='payment_method'>
                             <label class="text-[#353535] text-[14px] font-[jost] font-[400]" for="cod">
                                 Cash on Delivery</label>
                         </div>
                         <div class="my-[10px] flex items-center gap-[5px]">
                             <input id="online" name="payment_method" class="w-[14px] h-[14px] accent-[#380D37]"
                                 type="radio" value="online"
                                 wire:model='payment_method'>
                             <label class="text-[#353535] text-[14px] font-[jost] font-[400]" for="online">
                                 Online Payment</label>
                         </div>

                         <div>
                             <div class="my-[9px]">
                                 <h1 class="text-[#353535] text-[14px] font-[jost] font-[400]">We Accept:</h1>
                             </div>
                             <div class="my-[8px]">
                                 <img src="/storage/product/payment.svg" alt="">
                             </div>
                         </div>
                     </div>

                     
                     <div class="border-[#380D37] border-[3px] rounded-[4px] p-[20px] flex flex-col">

                         <div class="flex gap-[15px] font-[jost] font-[500] text-center my-[10px]">
                             <div
                                 class="w-[22px] h-[22px] bg-[#380D37] text-[#f2f2f2] rounded-[100%] text-center mt-[5px]">
                                 <h1>3</h1>
                             </div>
                             <div>
                                 <h1
                                     class="text-[#380D37] text-[20px] font-[jost] font-[500] tracking-[.5px] text-center">
                                     Delivery Method
                                </h1>
                             </div>
                         </div>
                         <div class="my-[10px]">
                             <h1 class="text-[#353535] text-[16px] font-[jost] font-[400]">Select Delivery Method
                             </h1>
                         </div>
                         <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $shippings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <div class="my-[10px] flex items-center gap-[5px]">
                                 <input <?php if($loop->first): echo 'checked'; endif; ?> name="shipping_id"
                                     id="shipping<?php echo e($shipping->id); ?>"
                                     value="<?php echo e($shipping->id); ?>" class="w-[14px] h-[14px] accent-[#380D37]"
                                     type="radio" wire:model='shipping_id' @change="shipChange(<?php echo e($shipping->price); ?>)">
                                 <label class="text-[#353535] text-[14px] font-[jost] font-[400]"
                                     for="shipping<?php echo e($shipping->id); ?>">
                                     <?php echo e($shipping->type . '- ' . $shipping->price . ' Taka ' . $shipping->through ?? ''); ?></label>
                             </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                     </div>
                 </div>

                 <!-- ----------order-view--section-------- -->
                 <div
                     class="overflow-x-auto border-[#380D37] border-[3px] rounded-[5px] mt-[35px] pl-[20px] pt-[20px] pr-[20px]">
                     <div class="overflow-x-auto flex gap-[15px] font-[jost] font-[500] text-center my-[10px]">
                         <div
                             class="w-[22px] h-[22px] bg-[#380D37] text-[#f2f2f2] rounded-[100%] text-center mt-[5px]">
                             <h1>4</h1>
                         </div>
                         <div>
                             <h1 class="text-[#380D37] text-[20px] font-[jost] font-[500] tracking-[.5px] text-center">
                                 Order Overview</h1>
                         </div>
                     </div>
                     <div class="">
                         <table class="text-[#380D37] text-[12px] font-[jost] font-[700] min-w-full">
                             <thead>
                                 <tr class="border-b-[rgba(#00000033] border-b-[1px] py-[20px] text-left">
                                     <th>Product Name</th>
                                     <th class="text-right py-[10px] text-[12px] font-[jost] font-[700]">
                                         Price
                                     </th>
                                     <th class="text-right text-[12px] font-[jost] font-[700]">
                                         Total
                                     </th>
                                 </tr>
                             </thead>
                             <tbody>
                                 <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <tr class="border-b-[rgba(#00000033] border-b-[1px] font-[jost]">
                                         <td
                                             class="max-sm:w-[130px] max-sm:text-[10px] text-[12px] font-[500] py-[10px]">
                                             <?php echo e($cart->product->title); ?>

                                         </td>
                                         <td
                                             class="text-right text-[12px] max-sm:text-[10px] font-[700] text-[#353535]">
                                             <?php echo e($cart->price); ?> Taka x <?php echo e($cart->quantity); ?>

                                         </td>
                                         <td
                                             class="text-right text-[#DC275C] text-[12px] max-sm:text-[10px] font-[700]">
                                             <?php echo e(number_format($cart->amount)); ?>.00 Taka
                                         </td>
                                     </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                 <tr class="border-b-[rgba(#00000033] border-b-[1px] font-[jost]">
                                     <td></td>
                                     <td
                                         class="text-right py-[10px] text-[12px] max-sm:text-[10px] font-[700] text-[#353535]">
                                         Sub Total:
                                     </td>
                                     <td class="text-right text-[#DC275C]  text-[12px] max-sm:text-[10px] font-[700]">
                                         <span x-text="mFormat(sub_total)"></span> Taka
                                     </td>
                                 </tr>
                                 <tr class="border-b-[rgba(#00000033] border-b-[1px] font-[jost]">
                                     <td></td>
                                     <td
                                         class="text-right py-[10px] text-[12px] max-sm:text-[10px] font-[700] text-[#353535]">
                                         Delivery
                                         Charge:
                                     </td>
                                     <td class="text-right text-[#DC275C] text-[12px] max-sm:text-[10px] font-[700]">
                                         <span x-text='shipping_price'></span> Taka
                                     </td>
                                 </tr>
                                 <tr class="border-b-[rgba(#00000033] border-b-[1px] font-[jost]">
                                     <td></td>
                                     <td
                                         class="text-right py-[10px] text-[12px] max-sm:text-[10px] font-[700] text-[#353535]">
                                         Discount:
                                     </td>
                                     <td class="text-right text-[#DC275C] text-[12px] max-sm:text-[10px] font-[700]">
                                         <span x-text='discount'></span>
                                     </td>
                                 </tr>
                                 <tr class="border-b-[rgba(#00000033] border-b-[1px] font-[jost]">
                                     <td></td>
                                     <td
                                         class="text-right py-[10px] text-[12px] max-sm:text-[10px] font-[700] text-[#353535]">
                                         Total:
                                     </td>
                                     <td class="text-right text-[#DC275C] text-[12px] max-sm:text-[10px] font-[700]">
                                         <span x-text="mFormat(all_total)"></span> Taka
                                     </td>
                                 </tr>
                             </tbody>
                         </table>
                     </div>
                 </div>
             </div>
         </section>

         <div class="mt-6">
             <!--[if BLOCK]><![endif]--><?php if($err_msg): ?>
             <span class="text-[red] block text-right mb-1"><?php echo e($err_msg); ?></span>
             <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
             <button
                 class="fill-up-btn ml-auto flex justify-center items-center rounded-[4px] px-[20px] py-[10px] text-[16px] text-center text-[#f2f2f2] font-[jost] font-[500] bg-gradient-to-r from-[#380D37] to-[#DC275C]">
                 Confirm Order
                 <div wire:loading wire:target='orderSubmit'
                     class="inline-block ml-2 h-6 w-6 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] text-success motion-reduce:animate-[spin_1.5s_linear_infinite]"
                     role="status">
                     <span
                         class="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">Loading...
                     </span>
                 </div>
             </button>

         </div>
     </form>
 </div>
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/livewire/checkout.blade.php ENDPATH**/ ?>