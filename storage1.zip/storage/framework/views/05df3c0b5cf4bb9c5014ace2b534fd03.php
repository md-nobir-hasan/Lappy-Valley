<div
    class=" p360 px-[100px] max-2xl:px-[70px] max-xl:px-[60px] max-lg:px-[38px] max-md:px-[35px] max-sm:px-[8px] max-sm:mt-[70px] max-xl:mt-[100px]">
    
    <!--[if BLOCK]><![endif]--><?php if($error = session('error')): ?>
        <script>
            toastr.success("<?php echo e($error); ?>")
        </script>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if($success = session('success')): ?>
        <script>
            toastr.success("<?php echo e($success); ?>")
        </script>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    <!-- Hero Section  -->
    <!--[if BLOCK]><![endif]--><?php if($home_banner): ?>
        <section class="w-full mx-auto">
            <div class="px-auto w-full mx-auto relative items-center" x-data="{ active: true }">
                <?php
                    $bnrs = explode(',', $home_banner->photo);
                ?>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bnrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="<?php echo e($loop->first ? '' : ' hidden'); ?> slide w-full">
                        <img class="w-full mx-auto object-cover" src="<?php echo e($banner); ?>">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->

                <!-- The previous button -->
                <div class="w-full mx-auto absolute top-0 bottom-0 flex justify-between items-center">
                    <a id="move_back" value='0'
                        class="slide_icon sm:translate-x-[-40px] text-[40px] text-blue-500 opacity-50 hover:opacity-100 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-12 h-12">
                            <path stroke-linecap="round" class="max-sm:stroke-[#f2f2f2]"  stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
                          </svg>
                          
                    </a>
                    <!-- The next button -->
                    <a id="move_front" value='0'
                        class="slide_icon sm:translate-x-[40px]  text-[40px] text-blue-500 opacity-50 hover:opacity-100 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-12 h-12">
                            <path :class="{ 'text-blue-500': active }" class="max-sm:stroke-[#f2f2f2]" stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
                          </svg>
                          
                    </a>
                </div>
            </div>

        </section>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    <!-- --------hero--section --end ----  -->

    <!-- Feature Laptops -->
    <section class='mt-[50px]'>
        <div class="py-1 text-center">
            <h2
                class="font-[jost] text-[40px] font-[500] max-lg:text-[30px] max-md:text-[25px] max-sm:text-[24px] text-[#353535]">
                Featured Laptops </h2>
            <p
                class="font-[jost] text-[16px] font-[500] max-lg:text-[14px] max-md:text-[12px] max-sm:text-[12px] text-[#380D37]">
                The best we offer is here</p>
        </div>
        <div class="pt-[60px]">
            <button
                class="usa_btn w-[241px] max-xl:w-[200px] max-lg:w-[180px] max-md:w-[150px] max-sm:w-[100px] h-[48px] max-lg:h-[43px] max-md:h-[40px] max-sm:h-[35px] max-lg:text-[18px] max-md:text-[16px] max-sm:text-[14px]
                items-center text-center rounded-[4px] bg-[#380D37] text-[#F2F2F2] font-[500] text-[20px] font-[jost]">
                USA
            </button>
            <button
                class="asian_btn w-[241px] max-xl:w-[200px] max-lg:w-[180px] max-md:w-[150px] max-sm:w-[100px]  h-[48px] max-lg:h-[43px] max-md:h-[40px] max-sm:h-[35px] max-lg:text-[18px] max-md:text-[16px] max-sm:text-[14px]
                items-center text-center rounded-[4px] bg-[#F2F2F2] text-[#380D37] font-[500] text-[20px] font-[jost]">
                ASIAN
            </button>
            <div class="h-[2px] bg-[#380D37] rouned-[2px]"></div>
        </div>
        <!-- Product  -->
        <div class="usa_prds">
            <div
                class="grid grid-cols-5 max-sm:grid-cols-2 max-md:grid-cols-2 max-lg:grid-cols-3 max-xl:grid-cols-4 gap-2 mt-6 mb-[78px] max-sm:mb-[50px]">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $features->where('cat_id', 7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898 = $component; } ?>
<?php $component = App\View\Components\Product::resolve(['product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Product::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898)): ?>
<?php $component = $__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898; ?>
<?php unset($__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898); ?>
<?php endif; ?>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <div class="hidden asian_prds">
            <div
                class="grid grid-cols-5 max-md:grid-cols-2  max-lg:grid-cols-3 max-xl:grid-cols-4 gap-2 mt-6 mb-[78px] max-sm:mb-[50px]">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $features->where('cat_id', 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898 = $component; } ?>
<?php $component = App\View\Components\Product::resolve(['product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Product::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898)): ?>
<?php $component = $__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898; ?>
<?php unset($__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898); ?>
<?php endif; ?>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </section>
    <!-- New arrival  -->
    <section>
        <!-- heading -->
        <div
            class=" fill-up-btn h-[130px] max-sm:h-[52px] max-md:h-[68px] max-lg:h-[85px] max-xl:h-[100px]  flex justify-center items-center text-white bg-gradient-to-r from-[#380D37] to-[#DC275C]">

            <h1
                class="text-[40px] max-sm:text-[18px] max-md:text-[22px] max-lg:text-[30px] max-xl:text-[35px] text-[#f2f2f2] font-[jost] font-[500] text-center">
                New Arrival</h1>
        </div>

        <!-- banner  -->
        <div class="grid grid-cols-3 max-sm:grid-cols-1 max-md:grid-cols-1 mt-6 mb-5 max-sm:mt-[.5rem]">
            <div class="">
                <div
                    class="pt-[20px] max-lg:pt-[2px] flex justify-center font-[jost] font-[500]
                     text-[52px] max-sm:text-[40px] max-md:text-[52px] max-lg:text-[31px] max-xl:text-[38px] xl:text-[48px] text-[#DC275C] ">
                    <p
                        class="max-sm:text-center max-md:text-center leading-[75.14px] max-xl:leading-[64.14px] max-lg:leading-[48px] max-sm:leading-[50px]">
                        Our newest</br>products are</br>here,just for you!</p>
                </div>
                <div class='flex justify-center items-center'>
                    <a href="<?php echo e(route('new_product', 'new_product')); ?>" wire:navigate
                        class="fill-up-btn linear px-[20px] py-[10px] mt-[20px] font-[jost] font-[500] text-[16px] text-[#F2F2F2] rounded-[4px]">
                        Visit Now
                    </a>
                </div>
            </div>

            <div class="col-span-2 max-md:mt-[20px]">
                <img class="" src="/storage/product/Hero-Image.svg" alt="">
            </div>
        </div>
    </section>
    <!-- Product  -->
    <section>
        <div
            class="grid grid-cols-5 max-md:grid-cols-2 max-lg:grid-cols-3 max-xl:grid-cols-4 gap-2 mt-6 mb-[78px] max-sm:mb-[50px]">
            
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $new_arrival->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898 = $component; } ?>
<?php $component = App\View\Components\Product::resolve(['product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Product::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898)): ?>
<?php $component = $__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898; ?>
<?php unset($__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </div>
    </section>
    <!-- Product  -->
    <!-- Feature Laptops Sliders -->
    <section>
        <div class="py-1 text-center">
            <h2
                class="font-[jost] text-[40px] font-[500] max-lg:text-[30px] max-md:text-[25px] max-sm:text-[24px] text-[#353535]">
                Featured Laptops</h2>
            <p
                class="font-[jost] text-[16px] font-[500] max-lg:text-[14px] max-md:text-[12px] max-sm:text-[12px] text-[#380D37]">
                The best we offer is here</p>
        </div>
        <div class="pt-[60px] max-sm:pt-[25px] max-md:pt-[30px] max-lg:pt-[40px] max-xl:pt-[50px]">
            <button
                class="usa_btn w-[241px] max-xl:w-[200px] max-lg:w-[180px] max-md:w-[150px] max-sm:w-[100px]  h-[48px] max-lg:h-[43px] max-md:h-[40px] max-sm:h-[35px] max-lg:text-[18px] max-md:text-[16px] max-sm:text-[14px]
                items-center text-center rounded-[4px] text-[#F2F2F2] bg-[#380D37] font-[500] text-[20px] font-[jost]">
                USA
            </button>
            <button
                class="asian_btn w-[241px] max-xl:w-[200px] max-lg:w-[180px] max-md:w-[150px] max-sm:w-[100px]  h-[48px] max-lg:h-[43px] max-md:h-[40px] max-sm:h-[35px] max-lg:text-[18px] max-md:text-[16px] max-sm:text-[14px]
                items-center text-center rounded-[4px] bg-[#F2F2F2] text-[#380D37] font-[500] text-[20px] font-[jost]">
                Asian
            </button>
            <div class="h-[2px] bg-[#380D37]"></div>
        </div>

        
        

        

        
        <div class="usa_prds">
            <!-- Swiper -->
            <div class="swiper mySwiper">
                <div class="swiper-wrapper mt-[20px] mb-[10px]">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $features->where('cat_id', 7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div
                                class="w-[221px] h-[376px] max-xl:w-full mx-auto max-sm:mb-[10px] max-md:mb-[10px] max-md:gap-[8px] flex flex-col bg-white px-2 pt-2 pb-3 gap-[16px] text-left shadow-[2px_2px_5px_2px_#0000001A]">

                                <div class="image-container h-[180px]">
                                    <a href="<?php echo e(route('product.details', [$f_product->slug])); ?>" wire:navigate class="h-full">
                                        <img src="<?php echo e($f_product->img()[0]); ?>" alt="" class=" img-contain h-full object-contain">
                                    </a>
                                </div>
                                <div>
                                    <a href="<?php echo e(route('product.details', [$f_product->slug])); ?>" wire:navigate
                                        class="text-[16px] text-[#380D37] font-[jost] font-[500] leading-[23.12px] transition duration-300 ease-in-out hover:text-[#ef4a23] decoration-[#ef4a23] decoration-2 hover:underline hover:underline-offset-4">
                                        <?php echo e(Str::of($f_product->title)->words(5)); ?>

                                    </a>
                                </div>


                                <div
                                    class="flex justify-between text-[14px] mt-auto font-[jost] font-[700] leading-[20.23px]">
                                    <span class=" text-[#DC275C]">
                                        <?php echo e(number_format($f_product->final_price)); ?> TK
                                    </span>
                                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('add-to-cart', ['id' => $f_product->id,'button' => '<span class="text-[#380D37]">Add to Cart</span>']);

$__html = app('livewire')->mount($__name, $__params, 'HOMtjNs', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                    
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                
            </div>

            <!-- Swiper JS -->
            <!-- Initialize Swiper -->
        </div>

        
        <div class="hidden asian_prds">
            <!-- Swiper -->
            <div class="swiper mySwiper mt-[20px]">
                <div class="swiper-wrapper">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $features->where('cat_id', 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div
                                class="w-[221px] h-[376px] mx-auto max-sm:mb-[10px] max-md:mb-[10px] max-md:gap-[8px] flex flex-col bg-white px-2 pt-2 pb-3 gap-[16px] text-left shadow-[2px_2px_5px_2px_#0000001A]">

                                <div class="image-container h-[180px]">
                                    <a href="<?php echo e(route('product.details', [$a_product->slug])); ?>" wire:navigate class="h-full">
                                        <img src="<?php echo e($a_product->img()[0]); ?>" alt="" class="img-contain h-full object-contain">
k                                    </a>
                                </div>
                                <div class="">
                                    <a href="<?php echo e(route('product.details', [$a_product->slug])); ?>" wire:navigate
                                        class="text-[16px] text-[#380D37] font-[jost] font-[500] leading-[23.12px] transition duration-300 ease-in-out hover:text-[#ef4a23] decoration-[#ef4a23] decoration-2 hover:underline hover:underline-offset-4">
                                        <?php echo e($a_product->title); ?>

                                    </a>
                                </div>


                                <div
                                    class="flex justify-between text-[14px] mt-auto font-[jost] font-[700] leading-[20.23px]">
                                    <span class=" text-[#DC275C]">
                                        <?php echo e(number_format($a_product->final_price)); ?> TK
                                    </span>
                                    <a class="text-[#380D37]">
                                        Add to Cart
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                    
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
            <!-- Initialize Swiper -->
        </div>
    </section>
    <div class='mt-[40px] mb-[30px]'>
        <div class="h-[2px] bg-[#380D37]"></div>
    </div>

    <!-- Differential Variants  -->
    <section class='mt-[70px] max-sm:mt-[22px]'>
        <div class="py-1 text-center">
            <h2
                class="font-[jost] text-[40px] font-[500] max-lg:text-[30px] max-md:text-[25px] max-sm:text-[24px] text-[#353535]">
                Differential Variants </h2>
            <p
                class="font-[jost] text-[16px] font-[500] max-lg:text-[14px] max-md:text-[12px] max-sm:text-[12px] text-[#380D37]">
                The best we offer is here</p>
        </div>
        <div class="pt-[60px]">
            <button
                class="usa_btn w-[241px] max-xl:w-[200px] max-lg:w-[180px] max-md:w-[150px] max-sm:w-[100px]  h-[48px] max-lg:h-[43px] max-md:h-[40px] max-sm:h-[35px] max-lg:text-[18px] max-md:text-[16px] max-sm:text-[14px]
                items-center text-center rounded-[4px] text-[#F2F2F2] bg-[#380D37] font-[500] text-[20px] font-[jost]">
                USA
            </button>
            <button
                class="asian_btn w-[241px] max-xl:w-[200px] max-lg:w-[180px] max-md:w-[150px] max-sm:w-[100px]  h-[48px] max-lg:h-[43px] max-md:h-[40px] max-sm:h-[35px] max-lg:text-[18px] max-md:text-[16px] max-sm:text-[14px]
                items-center text-center rounded-[4px] bg-[#F2F2F2] text-[#380D37] font-[500] text-[20px] font-[jost]">
                Asian
            </button>
            <div class="h-[2px] bg-[#380D37]"></div>
        </div>
        
        
        <div class="usa_prds">
            <div
                class="grid grid-cols-5 max-md:grid-cols-2 max-lg:grid-cols-3 max-xl:grid-cols-4 gap-2 mt-6 mb-[78px] max-sm:mb-[50px]">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $dpds->where('cat_id', 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898 = $component; } ?>
<?php $component = App\View\Components\Product::resolve(['product' => $d_product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Product::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898)): ?>
<?php $component = $__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898; ?>
<?php unset($__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
        
        <div class="hidden asian_prds">
            <div
                class="grid grid-cols-5 max-md:grid-cols-2 max-lg:grid-cols-3 max-xl:grid-cols-4 gap-2 mt-6 mb-[78px] max-sm:mb-[50px]">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $dpds->where('cat_id', 7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898 = $component; } ?>
<?php $component = App\View\Components\Product::resolve(['product' => $da_product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Product::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898)): ?>
<?php $component = $__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898; ?>
<?php unset($__componentOriginal4912e54b47cc540c8c40bfbaaa4ad898); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <!-- See more button  -->

    </section>
    <div>
        <a href="<?php echo e(route('shop')); ?>" wire:navigate
            class="fill-up-btn items-center justify-center flex my-[60px] mx-auto text-[16px] text-[#F2F4F8] w-[116px] h-[44px] rounded-[4px] bg-gradient-to-r from-[#380D37] to-[#DC275C]">See
            More</a>

        <div class="h-[2px] bg-[#380D37]"></div>
    </div>
    <!-- Currention code from this line upto footer  -->
    <section class="#about-us">
        <div>
            <h2
                class="mt-8 font-[jost] font-[500] text-center text-[40px] max-lg:text-[30px] max-md:text-[25px] max-sm:text-[24px] text-[#353535]">
                Why Choose Us?</h2>
        </div>
        <div class="grid grid-cols-5 max-md:grid-cols-2 max-lg:grid-cols-3 max-xl:grid-cols-4 gap-2 my-[50px] ">
            <div
                class="rounded-[4px] shadow-[2px_2px_5px_2px_#0000001A] max-sm:mb-[10px] max-md:mb-[10px] max-lg:mb-[10px]">
                <div>
                    <div class='p-3 mx-auto w-[116px] h-[116px]'>
                        <div class='flex items-center mx-auto'>
                            <img class='w-[55.36px] h-[55.36px]' src="/storage/product/laptop-1.jpg" alt="Product">
                            <img class='w-[55.36px]' src="/storage/product/laptop.jpg" alt="Product">
                        </div>
                        <div class='flex items-center mx-auto'>
                            <img class='w-[55.36px] h-[55.36px]' src="/storage/product/web-traffic.jpg"
                                alt="Product">
                            <img class='w-[55.36px] h-[55.36px]' src="/storage/product/laptop-2.jpg" alt="Product">
                        </div>
                    </div>
                    <h2
                        class="h-[100px] px-1 py-4 text-[#DC275C] font-[jost] text-[24px] font-[500] leading-[35px] text-center ">
                        Wide Varieties</h2>
                </div>
                <div class="p-3 mt-auto">
                    <p class="font-[jost] text-[14px] font-[500] leading-[20px] text-left text-[#380D37]">
                        We have a
                        wide collection of laptops from different brands. We have brand new and pre-ownedlaptops in our
                        collection.</p>
                </div>
            </div>
            <div
                class="rounded-[4px] shadow-[2px_2px_5px_2px_#0000001A] max-sm:mb-[10px] max-md:mb-[10px] max-lg:mb-[10px]">
                <div>
                    <img class="p-3 mx-auto w-[116px] h-[116px]" src="/storage/product/trust-1.svg" alt="Product">
                    <h2
                        class="h-[100px] px-1 py-4 text-[#DC275C] font-[jost] text-[24px]  font-[500] leading-[35px] text-center ">
                        Trusted and Reliable</h2>
                </div>
                <div class="p-3 mt-auto">
                    <p class="font-[jost] text-[14px] font-[500] leading-[20px] text-left text-[#380D37]">
                        We are
                        trusted and reliable shop. We provide you with the best services and good quality products.</p>
                </div>
            </div>

            <div
                class="rounded-[4px] shadow-[2px_2px_5px_2px_#0000001A] max-sm:mb-[10px] max-md:mb-[10px] max-lg:mb-[10px]">
                <div>
                    <img class="p-3 mx-auto w-[116px] h-[116px]" src="/storage/product/best-service.svg"
                        alt="Product">
                    <h2
                        class="h-[100px] px-1 py-4 text-[#DC275C] font-[jost] text-[24px] font-[500] leading-[35px] text-center ">
                        Best Service</h2>
                </div>
                <div class="p-3 mt-auto">
                    <p class="font-[jost] text-[14px] font-[500] leading-[20px] text-left text-[#380D37]">
                        We provide
                        you with the best after sell services. Any problem, you take it to us and we will solve it.</p>
                </div>
            </div>
            <div
                class=" rounded-[4px] shadow-[2px_2px_5px_2px_#0000001A] max-sm:mb-[10px] max-md:mb-[10px] max-lg:mb-[10px]">
                <div>
                    <img class="p-3 mx-auto w-[116px] h-[116px]" src="/storage/product/best-price-1.svg"
                        alt="Product">
                    <h2
                        class="h-[100px] px-1 py-4 text-[#DC275C] font-[jost] text-[24px] font-[500] leading-[35px] text-center ">
                        Best Price in Market</h2>
                </div>
                <div class="p-3 mt-auto">
                    <p class="font-[jost] text-[14px] font-[500] leading-[20px] text-left text-[#380D37]">
                        We will give
                        you the best and lowest possible price in market.</p>
                </div>
            </div>
            <div
                class="rounded-[4px] shadow-[2px_2px_5px_2px_#0000001A] max-sm:mb-[10px] max-md:mb-[10px] max-lg:mb-[10px]">
                <div class="">
                    <img class="p-3 mx-auto w-[116px] h-[116px]" src="/storage/product/fast-delivery-1.svg"
                        alt="Product">

                    <h2
                        class="h-[100px] px-1 py-4 text-[#DC275C] font-[jost] text-[24px] font-[500] leading-[35px] text-center ">
                        Fast Delivary</h2>
                </div>
                <div class="p-3 mt-auto">
                    <p class="font-[jost] text-[14px] font-[500] leading-[20px] text-left text-[#380D37]">
                        We deliver
                        our products carefully as fast as possible at your door step.</p>
                </div>
            </div>
    </section>
    <!-- What our client says  -->
    <section class="mt-16 max-xl:mt-4">
        <h2
            class="mb-12 max-lg:mb-4 font-[jost] font-[500] text-center text-[42px] max-lg:text-[30px] max-md:text-[25px] max-sm:text-[24px] text-[#353535]">
            What Our Clients Say About
            Us</h2>
        <div class="container mx-auto">

            <section id="slider" class="pt-5 mx-auto">
                <div class="container mx-auto">
                    
                    <div class="slider">
                        <div class="owl-carousel">
                            <div
                                class="slider-card rounded-[16px] py-4 px-4 bg-[#fff] shadow-[2px_2px_5px_2px_#0000001A]">
                                <div class="">
                                    <div class="flex justify-center">
                                        <div class="flex items-center">
                                            <div>
                                                <img class="rounded-[100%] w-[72px] h-[72px] client-img"
                                                    src="/storage/product/client-photo.svg" alt="">
                                            </div>
                                            <div class="ml-2">
                                                <h1
                                                    class="font-[Lato] font-[700] leo-h text-[24px] text-center text-[#353535]">
                                                    Leo</h1>
                                                <p
                                                    class="font-[Lato] font-[500] leo-p text-[18px] text-center text-[#353535]">
                                                    Lead Designer</p>
                                            </div>
                                        </div>

                                        <div class="flex star-div mt-[40px]  ml-auto">

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    height="22" class="star" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    height="22" class="star" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    height="22" class="star" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    height="22" class="star" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    height="22" class="star" viewBox="0 0 15 15"
                                                    fill="none">
                                                    <path
                                                        d="M7.5 1.25L9.43125 5.1625L13.75 5.79375L10.625 8.8375L11.3625 13.1375L7.5 11.1062L3.6375 13.1375L4.375 8.8375L1.25 5.79375L5.56875 5.1625L7.5 1.25Z"
                                                        stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>
                                        </div>
                                        <!-- </div> -->
                                    </div>
                                    <div>
                                        <h1
                                            class="my-[19px] leo-h1 leo-h1 font-[Lato] font-[700] text-[24px] text-center text-[#353535] leading-[28.8px]">
                                            It was a very good experience</h1>
                                    </div>
                                    <div>
                                        <p
                                            class="my-[17px] leo-p1 leo-p1 font-[jost] font-[500] text-[18px] leading-[23.13px] text-left text-[#353535]">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursusnibh mauris,
                                            nec turpis orci
                                            lectus maecenas.
                                            Suspendisse sed magnaeget nibh in turpis. Consequat duis diam lacus arcu.
                                            Faucibus venenatis
                                            felis id augue
                                            sit cursus pellentesqueenim arcu.Elementum felis magna pretium in tincidunt.
                                            Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacUSArcu.s
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="slider-card rounded-[16px] py-4 px-4 bg-[#fff] shadow-[2px_2px_5px_2px_#0000001A]">
                                <div class="">
                                    <div class="flex justify-center">
                                        <div class="flex items-center">
                                            <div>
                                                <img class="rounded-[100%] w-[72px] h-[72px] client-img"
                                                    src="/storage/product/client-photo.svg" alt="">
                                            </div>
                                            <div class="ml-2">
                                                <h1
                                                    class="font-[Lato] text-[24px] font-[700]  text-center text-[#353535] leo-h">
                                                    Leo</h1>
                                                <p
                                                    class="font-[Lato] text-[18px] font-[500] text-center text-[#353535] leo-p">
                                                    Lead Designer</p>
                                            </div>
                                        </div>

                                        <div class="flex mt-[40px] ml-auto star-div">

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 15 15"
                                                    fill="none">
                                                    <path
                                                        d="M7.5 1.25L9.43125 5.1625L13.75 5.79375L10.625 8.8375L11.3625 13.1375L7.5 11.1062L3.6375 13.1375L4.375 8.8375L1.25 5.79375L5.56875 5.1625L7.5 1.25Z"
                                                        stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>
                                        </div>
                                        <!-- </div> -->
                                    </div>
                                    <div>
                                        <h1
                                            class="my-[19px] leo-h1 font-[Lato] font-[700] text-[24px]  text-center text-[#353535] leading-[28.8px]">
                                            It was a very good experience</h1>
                                    </div>
                                    <div>
                                        <p
                                            class="my-[17px] leo-p1 font-[jost] font-[500] text-[18px] leading-[23.13px] text-left text-[#353535]">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursusnibh mauris,
                                            nec turpis orci
                                            lectus maecenas.
                                            Suspendisse sed magnaeget nibh in turpis. Consequat duis diam lacus arcu.
                                            Faucibus venenatis
                                            felis id augue
                                            sit cursus pellentesqueenim arcu.Elementum felis magna pretium in tincidunt.
                                            Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacUSArcu.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="slider-card rounded-[16px] py-4 px-4 bg-[#fff] shadow-[2px_2px_5px_2px_#0000001A]">
                                <div class="">
                                    <div class="flex justify-center">
                                        <div class="flex items-center">
                                            <div>
                                                <img class="rounded-[100%] w-[72px] h-[72px] client-img"
                                                    src="/storage/product/client-photo.svg" alt="">
                                            </div>
                                            <div class="ml-2">
                                                <h1
                                                    class="font-[Lato] text-[24px] font-[700]  text-center text-[#353535] leo-h">
                                                    Leo</h1>
                                                <p
                                                    class="font-[Lato] text-[18px] font-[500] text-center text-[#353535] leo-p">
                                                    Lead Designer</p>
                                            </div>
                                        </div>

                                        <div class="flex mt-[40px] ml-auto star-div">

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 15 15"
                                                    fill="none">
                                                    <path
                                                        d="M7.5 1.25L9.43125 5.1625L13.75 5.79375L10.625 8.8375L11.3625 13.1375L7.5 11.1062L3.6375 13.1375L4.375 8.8375L1.25 5.79375L5.56875 5.1625L7.5 1.25Z"
                                                        stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>
                                        </div>
                                        <!-- </div> -->
                                        <!-- </div> -->

                                    </div>
                                    <div>
                                        <h1
                                            class="my-[19px] leo-h1 font-[Lato] font-[700] text-[24px]  text-center text-[#353535] leading-[28.8px]">
                                            It was a very good experience</h1>
                                    </div>
                                    <div>
                                        <p
                                            class="my-[17px] leo-p1 font-[jost] font-[500] text-[18px] leading-[23.13px] text-left text-[#353535]">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursusnibh mauris,
                                            nec turpis orci
                                            lectus maecenas.
                                            Suspendisse sed magnaeget nibh in turpis. Consequat duis diam lacus arcu.
                                            Faucibus venenatis
                                            felis id augue
                                            sit cursus pellentesqueenim arcu.Elementum felis magna pretium in tincidunt.
                                            Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacUSArcu.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="slider-card rounded-[16px] py-4 px-4 bg-[#fff] shadow-[2px_2px_5px_2px_#0000001A]">
                                <div class="">
                                    <div class="flex justify-center">
                                        <div class="flex items-center">
                                            <div>
                                                <img class="rounded-[100%] w-[72px] h-[72px] client-img"
                                                    src="/storage/product/client-photo.svg" alt="">
                                            </div>
                                            <div class="ml-2">
                                                <h1
                                                    class="font-[Lato] text-[24px] font-[700]  text-center text-[#353535] leo-h">
                                                    Leo</h1>
                                                <p
                                                    class="font-[Lato] text-[18px] font-[500] text-center text-[#353535] leo-p">
                                                    Lead Designer</p>
                                            </div>
                                        </div>

                                        <div class="flex mt-[40px] ml-auto star-div">

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 15 15"
                                                    fill="none">
                                                    <path
                                                        d="M7.5 1.25L9.43125 5.1625L13.75 5.79375L10.625 8.8375L11.3625 13.1375L7.5 11.1062L3.6375 13.1375L4.375 8.8375L1.25 5.79375L5.56875 5.1625L7.5 1.25Z"
                                                        stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>
                                        </div>
                                        <!-- </div> -->
                                        <!-- </div> -->

                                    </div>
                                    <div>
                                        <h1
                                            class="my-[19px] leo-h1 font-[Lato] font-[700] text-[24px]  text-center text-[#353535] leading-[28.8px]">
                                            It was a very good experience</h1>
                                    </div>
                                    <div>
                                        <p
                                            class="my-[17px] leo-p1 font-[jost] font-[500] text-[18px] leading-[23.13px] text-left text-[#353535]">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursusnibh mauris,
                                            nec turpis orci
                                            lectus maecenas.
                                            Suspendisse sed magnaeget nibh in turpis. Consequat duis diam lacus arcu.
                                            Faucibus venenatis
                                            felis id augue
                                            sit cursus pellentesqueenim arcu.Elementum felis magna pretium in tincidunt.
                                            Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacUSArcu.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="slider-card rounded-[16px] py-4 px-4 bg-[#fff] shadow-[2px_2px_5px_2px_#0000001A]">
                                <div class="">
                                    <div class="flex justify-center">
                                        <div class="flex items-center">
                                            <div>
                                                <img class="rounded-[100%] w-[72px] h-[72px] client-img"
                                                    src="/storage/product/client-photo.svg" alt="">
                                            </div>
                                            <div class="ml-2">
                                                <h1
                                                    class="font-[Lato] text-[24px] font-[700]  text-center text-[#353535] leo-h">
                                                    Leo</h1>
                                                <p
                                                    class="font-[Lato] text-[18px] font-[500] text-center text-[#353535] leo-p">
                                                    Lead Designer</p>
                                            </div>
                                        </div>

                                        <div class="flex mt-[40px] ml-auto star-div">

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 15 15"
                                                    fill="none">
                                                    <path
                                                        d="M7.5 1.25L9.43125 5.1625L13.75 5.79375L10.625 8.8375L11.3625 13.1375L7.5 11.1062L3.6375 13.1375L4.375 8.8375L1.25 5.79375L5.56875 5.1625L7.5 1.25Z"
                                                        stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>
                                        </div>
                                        <!-- </div> -->
                                        <!-- </div> -->

                                    </div>
                                    <div>
                                        <h1
                                            class="my-[19px] leo-h1 font-[Lato] font-[700] text-[24px]  text-center text-[#353535] leading-[28.8px]">
                                            It was a very good experience</h1>
                                    </div>
                                    <div>
                                        <p
                                            class="my-[17px] leo-p1 font-[jost] font-[500] text-[18px] leading-[23.13px] text-left text-[#353535]">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursusnibh mauris,
                                            nec turpis orci
                                            lectus maecenas.
                                            Suspendisse sed magnaeget nibh in turpis. Consequat duis diam lacus arcu.
                                            Faucibus venenatis
                                            felis id augue
                                            sit cursus pellentesqueenim arcu.Elementum felis magna pretium in tincidunt.
                                            Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacUSArcu.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="slider-card rounded-[16px] py-4 px-4 bg-[#fff] shadow-[2px_2px_5px_2px_#0000001A]">
                                <div class="">
                                    <div class="flex justify-center">
                                        <div class="flex items-center">
                                            <div>
                                                <img class="rounded-[100%] w-[72px] h-[72px] client-img"
                                                    src="/storage/product/client-photo.svg" alt="">
                                            </div>
                                            <div class="ml-2">
                                                <h1
                                                    class="font-[Lato] text-[24px] font-[700]  text-center text-[#353535] leo-h">
                                                    Leo</h1>
                                                <p
                                                    class="font-[Lato] text-[18px] font-[500] text-center text-[#353535] leo-p">
                                                    Lead Designer</p>
                                            </div>
                                        </div>

                                        <div class="flex mt-[40px] ml-auto star-div">

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 22 22"
                                                    fill="#FFA033">
                                                    <path
                                                        d="M11 1.8335L13.8325 7.57183L20.1667 8.49766L15.5833 12.9618L16.665 19.2685L11 16.2893L5.335 19.2685L6.41667 12.9618L1.83334 8.49766L8.1675 7.57183L11 1.8335Z"
                                                        fill="#FFA033" stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>

                                            <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="22"
                                                    class="star" height="22" viewBox="0 0 15 15"
                                                    fill="none">
                                                    <path
                                                        d="M7.5 1.25L9.43125 5.1625L13.75 5.79375L10.625 8.8375L11.3625 13.1375L7.5 11.1062L3.6375 13.1375L4.375 8.8375L1.25 5.79375L5.56875 5.1625L7.5 1.25Z"
                                                        stroke="#FFA033" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></a>
                                        </div>
                                        <!-- </div> -->
                                        <!-- </div> -->

                                    </div>
                                    <div>
                                        <h1
                                            class="my-[19px] leo-h1 font-[Lato] font-[700] text-[24px]  text-center text-[#353535] leading-[28.8px]">
                                            It was a very good experience</h1>
                                    </div>
                                    <div>
                                        <p
                                            class="my-[17px] leo-p1 font-[jost] font-[500] text-[18px] leading-[23.13px] text-left text-[#353535]">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cursusnibh mauris,
                                            nec turpis orci
                                            lectus maecenas.
                                            Suspendisse sed magnaeget nibh in turpis. Consequat duis diam lacus arcu.
                                            Faucibus venenatis
                                            felis id augue
                                            sit cursus pellentesqueenim arcu.Elementum felis magna pretium in tincidunt.
                                            Suspendisse sed magna eget nibh in turpis. Consequat duis diam lacUSArcu.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </section>
    <div class="mt-16 h-[2px] bg-[#380D37]"></div>
    <!-- Drop/submit a review  -->
    <section class="mt-16 mb-5 max-md:mt-6">
        <div
            class="text-center text-[#380D37] text-[42px] font-[jost] font-[500] max-md:my-[35px] leading-[61px] max-sm:leading-[5px]">
            <h1 class="max-sm:text-[34px] max-md:text-[45] max-lg:text-[] max-xl:text-[]"> Please Drop a Review!</h1>
        </div>
        <div
            class="grid grid-cols-2 max-sm:grid-cols-1 max-md:grid-cols-1 max-lg:grid-cols-2 mt-20 max-md:mt-12 max-sm:mt-[15px]">
            <div>
                <div>
                    <h1
                        class="text-[52px] text-[#DC275C] max-sm:text-[34px] max-md:text-[44] max-lg:text-[35px] max-xl:text-[45px] max-md:text-center font-[500] font-[jost] leading-[75.14px] max-sm:leading-[40px] max-md:leading-[60px] max-xl:leading-[52px]">
                        We Believe In The
                        </br> Power Of </br> Communication</h1>
                </div>
                <div>
                    <p
                        class="mt-8 text-[#353535] text-[24px] max-sm:text-[14px] max-md:text-[] max-lg:text-[20px] max-xl:text-[22px] max-md:text-center font-[jost] font-[500] leading-[30px] max-sm:leading-[20px]">
                        Share your
                        experience with us.</br> Drop a comment and we will look into it.</p>
                </div>
            </div>
            <form wire:submit="post"
                class="max-md:border-[1px] max-md:border-[#380D37] max-md:rounded-[4px] max-sm:p-[10px] max-md:p-[15px] max-sm:mt-[15px] max-md:my-[22px]">

                <div class="grid grid-cols-2 gap-2">
                    <input wire:model="name"
                        class=" h-[64px] max-sm:h-[40px] max-lg:h-[55px] rounded-[4px] bg-[#F2F2F2] font-[jost] text-[16px] max-sm:text-[12px] italic font-[500] leading-[23px] py-[8px] px-[16px] max-sm:pl-[12px]"
                        id="name" type="text" placeholder="Name*">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-[red] text-[12px]"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                    <input wire:model="email"
                        class=" h-[64px] max-sm:h-[40px] max-lg:h-[55px] rounded-[4px] bg-[#F2F2F2] font-[jost] text-[16px] max-sm:text-[12px] italic font-[500] leading-[23px]  py-[8px] px-[16px]"
                        id="email" type="email" placeholder="Email*">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-[red] text-[12px]"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                </div>
                <div>
                    <input wire:model="subject"
                        class=" h-[64px] max-sm:h-[40px] max-lg:h-[55px] rounded-[4px] w-full py-2 px-3 bg-[#F2F2F2] font-[jost] text-[16px] max-sm:text-[12px] mt-[20px] mb-[20px] italic font-[500] "
                        id="subject" type="text" placeholder="Subject(optional)">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-[red] text-[12px]"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                </div>
                <div>
                    <textarea wire:model='msg'
                        class="h-[271px] max-sm:h-[150px] max-lg:h-[220px] max-xl:h-[230px] rounded-[4px] w-full py-2 pb-32 px-3 bg-[#F2F2F2] font-[jost] text-[16px] max-sm:text-[12px]  italic font-[500] "
                        id="message" rows="4" placeholder=" Message"></textarea>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['msg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-[red] text-[12px]"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                </div>
                <div class="flex items-center max-md:justify-center">
                    <!--[if BLOCK]><![endif]--><?php if($post_success_msg): ?>
                        <span class="block text-[green]"><?php echo e($post_success_msg); ?></span>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($post_error_msg): ?>
                        <span class="block text-[red]"><?php echo e($post_error_msg); ?></span>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

                    <a class="fill-up-btn text-[#f2f2f2] text-center text-[16px] h-[44px] px-[40px] py-[10px] rounded-[4px] font-[500] font-[jost] mt-[15px]  bg-gradient-to-r from-[#380D37] to-[#DC275C] "
                        type="submit">
                        Post
                        <div wire:loading
                            class="absolute right-0 inline-block h-6 w-6 mr-2 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] text-success motion-reduce:animate-[spin_1.5s_linear_infinite]"
                            role="status">
                            <span
                                class="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">Loading...
                            </span>
                        </div>
                    </a>
                </div>
            </form>
        </div>
    </section>

    
</div>
    <?php
        $__scriptKey = '3604315873-0';
        ob_start();
    ?>
    <script>
        // ----hero--section---
        // Hero section slide
        $('#move_back').on('click', function() {
            console.log($(this).attr('value'));
            let current_slide = Number($(this).attr('value')) - 1;
            let total_slide = $('.slide').length;
            console.log(current_slide, total_slide, 'yes');
            // if(current_slide>=total_slide){
            //     current_slide == 1
            // }
            if (current_slide < 0) {

                current_slide = 2;
                console.log(current_slide, total_slide, 'after if');
            }
            $('.slide').hide();
            $('.slide').eq(current_slide).show();
            $('.slide_icon').attr('value', current_slide);
            $(this).addClass('slide-active');
            $('#move_front').removeClass('slide-active')
        })
        $('#move_front').on('click', function() {
            console.log($(this).attr('value'));
            let current_slide = Number($(this).attr('value')) + 1;
            let total_slide = $('.slide').length;
            console.log(current_slide, total_slide, 'yes');
            // if(current_slide>=total_slide){
            //     current_slide == 1
            // }
            if (current_slide > 2) {

                current_slide = 0;
                console.log(current_slide, total_slide, 'after if');
            }
            $('.slide').hide();
            $('.slide').eq(current_slide).show();
            $('.slide_icon').attr('value', current_slide);
            $(this).addClass('slide-active');
            $('#move_back').removeClass('slide-active')
        });
        // hero---section--end-----
        $(document).ready(function() {
            $('.usa_btn').each(function(index) {
                $(this).on('click', function() {
                    $(this).addClass('bg-[#380D37] text-[#F2F2F2]');
                    $(this).removeClass('bg-[#F2F2F2] text-[#380D37]');
                    $('.asian_btn').eq(index).removeClass('bg-[#380D37] text-[#F2F2F2]')
                    $('.asian_btn').eq(index).addClass('bg-[#F2F2F2] text-[#380D37]');
                    $('.asian_prds').eq(index).hide();
                    $('.usa_prds').eq(index).show();
                });
            });
            $('.asian_btn').each(function(index) {
                $(this).on('click', function() {
                    $(this).addClass('bg-[#380D37] text-[#F2F2F2]');
                    $(this).removeClass('bg-[#F2F2F2] text-[#380D37]');
                    $('.usa_btn').eq(index).removeClass('bg-[#380D37] text-[#F2F2F2]')
                    $('.usa_btn').eq(index).addClass('bg-[#F2F2F2] text-[#380D37]');
                    $('.usa_prds').eq(index).hide();
                    $('.asian_prds').eq(index).show();

                });
            });

            $(".owl-carousel").owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                dots: true,
                autoplay: true,
                autoplayTimeout: 3000,
                autoplayHoverPause: true,
                center: true,
                navText: [
                    '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-18 h-9 arrow"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" /></svg>',
                    '<svg xmlns="http:www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-18 h-9 arrow"><path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" /> </svg>'
                ],
                responsive: {
                    0: {
                        items: 1,
                       
                    },
                    640: {
                        items: 1,
                       
                       
                    },
                    1024: {
                        items: 3,
                      
                       
                    }
                }
            });
        });
        var swiper = new Swiper(".mySwiper", {
            slidesPerView: 5,
            spaceBetween: 5,
            // freeMode: true,
            // cssMode: true,
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
            // pagination: {
            //     el: ".swiper-pagination",
            // },
            mousewheel: true,
            keyboard: true,
            breakpoints: {
                // when window width is >= 320px
                300: {
                    slidesPerView: 2,
                    spaceBetween: 2
                },
                // when window width is >= 480px
                // 640: {
                // slidesPerView: 2,
                // spaceBetween: 20
                // },
                768: {
                    slidesPerView: 3,
                    spaceBetween: 5
                },
                1024: {
                    slidesPerView: 4,
                    spaceBetween: 5
                },
                1280: {
                    slidesPerView: 5,
                    spaceBetween: 5
                },
                // ...
            }

        });
    </script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/livewire/home-page.blade.php ENDPATH**/ ?>