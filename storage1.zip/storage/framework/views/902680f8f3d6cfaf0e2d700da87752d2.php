

    
    <span  id="<?php echo e($id); ?>" class="cursor-pointer add-to-cart">
            <?php echo $button; ?>

    </span>
    

<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/livewire/add-to-cart.blade.php ENDPATH**/ ?>