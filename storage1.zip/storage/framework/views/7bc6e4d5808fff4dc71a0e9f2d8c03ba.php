 <div
     class="bg-[#F2F2F2] h-[51px] py-4 2xl:px-[100px] xl:px-[50px] max-xl:hidden flex justify-between text-center items-center">
     <div class="relative">
         <span class="flex items-center whitespace-nowrap rounded font-[jost] font-[500] text-[#353535] text-[16px] bg-[#f2f2f2]"
              type="button" id="dropdownMenuButton2">
             <a class="nav-color" href="<?php echo e(route('shop')); ?>" wire:navigate> All Categories</a>
             <span class="w-2 ml-2 cursor-pointer menue">
                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-5 h-5">
                     <path fill-rule="evenodd"
                         d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z"
                         clip-rule="evenodd" />
                 </svg>
             </span>
         </span>
         <ul
             class="submenu absolute z-[1000] float-left p-2 hidden w-[200px] list-none overflow-hidden border-none bg-[#f2f2f2] text-[#353535] text-left [&[data-te-dropdown-show]]:block">
             <li
                 class="border-b-[1px] border-[#380D37] hover:bg-[#380D37] hover:text-[#f2f2f2] active:bg-[#380D37] active:text-[#f2f2f2]">
                 <a class="block w-full whitespace-nowrap px-4 py-2 font-[jost] font-[500] text-[16px] text-[#35353]"
                     href="<?php echo e(route('shop')); ?>" wire:navigate>All</a>
             </li>
             <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li
                     class="border-b-[1px] border-[#380D37] hover:bg-[#380D37] hover:text-[#f2f2f2] active:bg-[#380D37] active:text-[#f2f2f2]">
                     <a class="nav-color hover-colors block w-full whitespace-nowrap px-4 py-2 font-[jost] font-[500] text-[16px] text-[#35353]"
                         href="<?php echo e(route('cate_wise.shop', [$menu->slug])); ?>" wire:navigate><?php echo e($menu->title); ?></a>
                 </li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
         </ul>
     </div>
     <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $men): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if(count($men->child_cat)>0): ?>
             <div class="relative">
                 <span class="flex items-center whitespace-nowrap rounded font-[jost] font-[500] text-[#353535] text-[16px] bg-[#f2f2f2]"
                    type="button" id="dropdownMenuButton2">
                     <a class="nav-color" href="<?php echo e(route('cate_wise.shop', [$men->slug])); ?>" wire:navigate><?php echo e($men->title); ?></a>
                     <span class="w-2 ml-2 cursor-pointer menue">
                         <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"
                             class="w-5 h-5">
                             <path fill-rule="evenodd"
                                 d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z"
                                 clip-rule="evenodd" />
                         </svg>
                     </span>
                 </span>
                 <ul
                     class="nav-colors1 submenu absolute z-[1000] float-left p-2  hidden w-[200px] list-none overflow-hidden border-none bg-[#f2f2f2] text-[#353535] text-left [&[data-te-dropdown-show]]:block">
                     <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $men->child_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <li
                             class="w-full border-b-[1px] border-[#380D37] hover:bg-[#380D37] hover:text-[#f2f2f2] active:bg-[#380D37] active:text-[#f2f2f2]">
                             <a class="nav-color hover-colors block w-full whitespace-nowrap px-4 py-2 font-[jost] font-[500] text-[16px] text-[#35353]"
                                 href="<?php echo e(route('cate_wise.shop', [$men->slug, $cc->slug])); ?>"
                                 wire:navigate><?php echo e($cc->title); ?></a>
                         </li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                 </ul>
             </div>
         <?php else: ?>
             <div class="relative">
                 <a class="nav-color flex items-center whitespace-nowrap rounded font-[jost] font-[500] text-[#353535] text-[16px] bg-[#f2f2f2]"
                     href="<?php echo e(route('cate_wise.shop', [$men->slug])); ?>" wire:navigate type="button" id="dropdownMenuButton2">
                     <?php echo e($men->title); ?>


                 </a>
             </div>
         <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->

     <div class="relative">
         <a class="nav-color flex items-center whitespace-nowrap rounded font-[jost] font-[500] text-[#353535] text-[16px] bg-[#f2f2f2]"
             href="tel:0171264420">
             Hotline: +8880171264420            
         </a>
     </div>
 </div>
     <?php
        $__scriptKey = '296374364-0';
        ob_start();
    ?>
     <script>
         $(document).ready(function() {
             $('.menue').each(function(index) {
                 $(this).on('click', function() {
                     if ($('.submenu').eq(index).is(':hidden')) {
                         console.log('i am hidden')
                         $('.submenu').hide(200);
                         $('.submenu').eq(index).show(200);
                     } else {
                         // $('.submenu').hide(200);
                         console.log('i am vissible');
                         $('.submenu').eq(index).hide(200);
                     }
                 })
             })
         })
     </script>
     <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/livewire/nav.blade.php ENDPATH**/ ?>