<div>
   <h1> Your password is <?php echo e($password); ?></h1>
</div>
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/mail/password-send.blade.php ENDPATH**/ ?>