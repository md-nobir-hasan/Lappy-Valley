<div>
      <div class='ml-[40px]'>
        <h1 class='font-[jost] xl:text-[20px] font-[400] leading-[25.3px] text-[#353535]'>All Categories/ Brand New</h1>
        <div class='h-1 bg-[#764A8733]'></div>
    </div>

    <!-- Sidenav -->
    <div class="container mx-auto mt-4">
        <div class="flex justify-between gap-8">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('side-nav', []);

$__html = app('livewire')->mount($__name, $__params, 'SwQJaZy', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <!-- ------------right---part--start--- -->

            <div class="mt-2">
              <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('menu-nav', []);

$__html = app('livewire')->mount($__name, $__params, 'KpHc4Lw', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <!-- ------cart--group----1st--part--- -->

                <div class='grid grid-cols-4 gap-8 mt-4'>
                    <!--[if BLOCK]><![endif]--><?php for($i=1;$i<25;$i++): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('shop-product', []);

$__html = app('livewire')->mount($__name, $__params, '8fpNUSe', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php endfor; ?> <!--[if ENDBLOCK]><![endif]-->
                </div>

            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/livewire/shop.blade.php ENDPATH**/ ?>