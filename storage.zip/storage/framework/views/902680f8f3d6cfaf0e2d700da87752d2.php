<span>
    <?php echo $button; ?>

</span>
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/livewire/add-to-cart.blade.php ENDPATH**/ ?>