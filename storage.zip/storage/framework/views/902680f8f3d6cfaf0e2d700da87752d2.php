<span class="cursor-pointer">
    <span  id="<?php echo e($id); ?>" class="flex items-center justify-center text-[10px] text-[#380D37] add-to-cart">

        <?php echo $button; ?>

    </span>
    
</span>
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/livewire/add-to-cart.blade.php ENDPATH**/ ?>