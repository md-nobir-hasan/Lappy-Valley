<div>
    I am about us page
</div>
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/livewire/about-us.blade.php ENDPATH**/ ?>