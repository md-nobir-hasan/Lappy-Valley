  <nav
      class=" px-3 flex justify-between items-center bg-[#F2F2F2] py-3 font-[jost] font-[600] text-[16px] leading-[30px] rounded-[6px]">
      <div class="">
          <h1>Brand New</h1>
      </div>
      <div class="flex justify-between font-[jost] font-[500] text-[17px]">
          <div class="">
              <label for="text">Show:</label>
              <select name="input-sort" class="py-[7px] pr-[6px] border-[1.5px] ">
                  <option value="20">20</option>
                  <option value="30">30</option>
                  <option value="30">30</option>
                  <option value="30">30</option>
              </select>
          </div>
          <div class="">
              <label for="text">Short By:</label>
              <select name="input-sort" class="py-[8px] pr-[40px] border-[1.5px]">>
                  <option value="20">Default</option>
                  <option value="30">30</option>
                  <option value="30">30</option>
                  <option value="30">30</option>
              </select>
          </div>
      </div>
  </nav>
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/livewire/menu-nav.blade.php ENDPATH**/ ?>