  <nav
      class=" px-3 flex justify-between items-center bg-[#F2F2F2] py-3 font-[jost] font-[600] text-[16px] leading-[30px] rounded-[6px]">
      <div class="">
          <h1>Brand New</h1>
      </div>

     <div class="flex justify-between text-center items-center gap-[10px] font-[jost] font-[500] text-[17px]">
    
    <label class=" bg-[#f2f2f2] text-[#380D37] text-[14px] font-[jost] font-[400] leading-[20.23px]">Stor by:</label>
    <select class="block w-[400px] px-[20px] py-[15px] mr-[80px] text-[#380D37] text-[14px] font-[jost] font-[400] leading-[20.23px]">
        <option selected>Default Storing</option>
        <option value="US">United States</option>
        <option value="CA">Canada</option>
        <option value="FR">France</option>
        <option value="DE">Germany</option>
    </select> 
    
    <div class="shop-view text-[#380D37] text-[14px] font-[jost] font-[400] leading-[20.23px] gap-[20px] mx-[20px]"><span>View</span>
    <a href="#" class="grid-view mf-shop-view current mx-[20px]" data-view="grid">
    <i class="fa fa-th" aria-hidden="true"></i></a>
      <a href="#" class="list-view mf-shop-view mx-[20px]" data-view="list"><i class="fa fa-list" aria-hidden="true"></i></i>
    </a></div>
    </div>

</nav>

              
         



        
<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/livewire/menu-nav.blade.php ENDPATH**/ ?>