
<div class="shadow-[2px_2px_5px_2px_#0000001A] p-2">
    <div class="bg-white rounded-lg product_div">
        <a href="<?php echo e(route('product.details', [$product->slug])); ?>">
            
            <!--[if BLOCK]><![endif]--><?php if($product->photo): ?>
                <?php
                    $photo = explode(',', $product->photo);
                    // dd($photo);
                ?>
                <img src="<?php echo e($photo[0]); ?>" class="object-center pimg" alt="<?php echo e($product->photo); ?>">
            <?php else: ?>
                <img src="<?php echo e(asset('backend/img/thumbnail-default.jpg')); ?>" class="object-center pimg" alt="avatar.png">
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </a>

        <div>
            <p class="ptitle font-[jost] text-[16px] font-[500] leading-[23px] text-left text-[#380D37] ">
                <?php echo e($product->title); ?>

            </p>
            <?php echo e($slot); ?>

            <div class="py-[12px] flex justify-between px-2">
                <a href="#" class="font-[jost] text-[14px] font-[600] leading-[20px] text-left text-[#DC275C]">
                    <span class="pprice"
                        value='<?php echo e($product->price); ?>'><?php echo e(number_format($product->price - ($product->price * $product->discount) / 100)); ?></span>
                    TK</a>
                
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('add-to-cart', ['id' => $product->id,'button' => '<p  class="font-[jost] text-[14px] text-[#380D37] font-[600] leading-[20px] text-left cursor-pointer ">Add to Cart</p>']);

$__html = app('livewire')->mount($__name, $__params, 'eCTxd1t', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\client-project\Lappy-Valley1.0.0\resources\views/components/product.blade.php ENDPATH**/ ?>